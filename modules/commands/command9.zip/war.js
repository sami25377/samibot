module.exports.config = { usePrefix: true,
    name: "war",
    version: "1.0.0",
    hasPermssion: 2,
    credits: "SAKIBIN",
    description: "War broke the boxchat",
    commandCategory: "nsfw",
    usages: "bold war",
    cooldowns: 10,
    dependencies: {
        "fs-extra": "",
        "axios": ""
    }
}

module.exports.run = async function({ api, args, Users, event}) {
 var mention = Object.keys(event.mentions)[0];
    
 let name =  event.mentions[mention];
    var arraytag = [];
        arraytag.push({id: mention});
    var a = function (a) { api.sendMessage(a, event.threadID); }
a("Listen to your father, kids !");
setTimeout(() => {a({body: "F*ck your mother" })}, 3000);
setTimeout(() => {a({body: "You little brats come out to listen to your father curse"})}, 5000);
setTimeout(() => {a({body: "Quick show the dogs" })}, 7000);
setTimeout(() => {a({body: "Show your father's soul" })}, 9000);
setTimeout(() => {a({body: "Do you guys like war so much?" })}, 12000);
setTimeout(() => {a({body: "Damn you guys too" })}, 15000);
setTimeout(() => {a({body: "Give your father the age of war" })}, 17000);
setTimeout(() => {a({body: "Hurry up and curse each other with me" })}, 20000);
setTimeout(() => {a({body: "Are the bad boys wrinkling their noses up to wage war on your father?" })}, 23000);
setTimeout(() => {a({body: "I fuck your mother" })}, 25000);
setTimeout(() => {a({body: "Delicious then yawn your mother up" })}, 28500);
setTimeout(() => {a({body: "Your father shot you to death by rapping" })}, 31000);
setTimeout(() => {a({body: "Please age eat me ?" })}, 36000);
setTimeout(() => {a({body: "If it's delicious, eat your dad" })}, 39000);
setTimeout(() => {a({body: "Before that, please give me a break for 1 minute" })}, 40000);
setTimeout(() => {a({body: "Please allow me to start" })}, 65000);
setTimeout(() => {a({body: "First of all, I would like to fuck you from top to bottom" })}, 70000);
setTimeout(() => {a({body: "I fuck from cunt hole to pussy cleavage" })}, 75000);
setTimeout(() => {a({body: "The cunt is as big as a buffalo's cunt masturbating a sewer pipe" })}, 80000);
setTimeout(() => {a({body: "I'm sure 2 guys like me aren't enough to fill your ass hole" })}, 85000);
setTimeout(() => {a("I'm tired and don't curse anymore")} , 90000);
setTimeout(() => {a({body: "Come on boss update the lyric, let's continue the war" })}, 95000);
setTimeout(() => {a({body: "Thank you for listening to me war" })}, 100000);
setTimeout(() => {a({body: "Goodbye and see you in the next program" })}, 105000);
setTimeout(() => {a({body: "Good bye 🥺"})} , 115000);




  
  }
